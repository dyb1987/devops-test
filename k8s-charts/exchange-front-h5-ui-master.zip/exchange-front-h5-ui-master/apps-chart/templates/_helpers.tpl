{{- define "app.resources" -}}
resources:
{{- if .Values.resources.limits.memory }}
  limits:
    memory: "{{ .Values.resources.limits.memory }}"
{{- end }}
  requests:
    memory: "{{ .Values.resources.requests.memory }}"
{{- end }}

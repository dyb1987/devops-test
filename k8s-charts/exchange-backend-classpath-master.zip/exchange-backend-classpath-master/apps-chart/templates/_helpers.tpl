{{- define "app.resources" -}}
resources:
  requests:
    memory: "{{ .Values.resources.requests.memory }}"
    {{- if ne .Values.resources.requests.cpu "__REQUESTS_CPU__" }}
    cpu: "{{ .Values.resources.requests.cpu }}"
    {{- end }}
{{- if .Values.resources.limits.memory }}
  limits:
    memory: "{{ .Values.resources.limits.memory }}"
    {{- if ne .Values.resources.limits.cpu "__LIMIT_CPU__" }}
    cpu: "{{ .Values.resources.limits.cpu }}"
    {{- end }}
  {{- else if ne .Values.resources.limits.cpu "__LIMIT_CPU__" }}
  limits:
    cpu: "{{ .Values.resources.limits.cpu }}"
{{- end }}
{{- end }}

{{- define "app.service" -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.service.name }}
  namespace: apps
spec:
  type: ClusterIP
  selector:
    {{- range $k, $v := .Values.labels }}
    {{ $k }}: {{ $v }}
    {{- end }}
  ports:
  {{- range .Values.service.port }}
  - port: {{ . }}
    targetPort: {{ . }}
    name: http-{{ . }}
  {{- end }}
{{- end }}

{{- define "app.affinity" -}}
{{- if eq .Values.name "robot-provider" -}}
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
          - {key: service, operator: In, values: ["elasticsearch"]}
        namespaces:
        - service
        topologyKey: kubernetes.io/hostname
  podAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
    - labelSelector:
        matchExpressions:
        - {key: app, operator: In, values: ["api"]}
      namespaces:
      - apps
      topologyKey: kubernetes.io/hostname
{{- else if eq .Values.name "api" -}}
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
          - {key: service, operator: In, values: ["elasticsearch"]}
        namespaces:
        - service
        topologyKey: kubernetes.io/hostname
  podAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
          - {key: app, operator: In, values: ["robot-provider"]}
        namespaces:
        - apps
        topologyKey: kubernetes.io/hostname
{{- end }}
{{- end }}

{{- define "app.leveldbMount" -}}
{{- if eq .Values.name "matching-provider" -}}
- name: leveldb
  mountPath: /data
{{- end }}
{{- end }}

{{- define "app.leveldbPvc" -}}
{{- if eq .Values.name "matching-provider" -}}
- name: leveldb
  persistentVolumeClaim:
    claimName: leveldb-pvc
{{- end }}
{{- end }}

{{- define "app.leveldbInit" -}}
{{- if eq .Values.name "matching-provider" -}}
initContainers:
- name: init
  image: k8s-harbor.exchange.local/{{ .Values.image.repository }}/{{ .Values.image.name }}:{{ .Values.image.tag}}
  imagePullPolicy: Always
  command: ["sh", "-c", "chown -R 2000:2000 /data"]
  securityContext:
    privileged: true
    runAsUser: 0
    capabilities:
      add: ["CHOWN", "SYS_ADMIN"]		
  volumeMounts:
  - name: leveldb
    mountPath: /data
{{- end }}
{{- end }}

